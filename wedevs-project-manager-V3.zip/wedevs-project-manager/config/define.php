<?php
return [
	'path'       => dirname( dirname( __FILE__ ) ),
	'url'        => plugin_dir_url( dirname( __FILE__ ) ),
    'view_path'  => dirname( dirname( __FILE__ ) ) . '/views',
];
       
